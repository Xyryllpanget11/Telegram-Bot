const axios = require("axios");

class Simsimi {
    constructor() {
        this.api_url = "https://simsimi.fun/api/v2/";
    }

    async getMessage(yourMessage, langCode = "en") {
        try {
            const response = await axios.get(this.api_url, {
                params: {
                    mode: "talk",
                    lang: langCode,
                    message: yourMessage,
                    filter: "true"
                }
            });

            if (response.status === 200) {
                const responseData = await response.data;
                if (responseData.success) {
                    return responseData.success;
                } else {
                    throw new Error("API returned a non-successful message");
                }
            } else {
                throw new Error("API returned an error");
            }
        } catch (err) {
            console.error("Error while getting a message:", err);
            throw err;
        }
    }
}

// Example usage:
const simsimi = new Simsimi();

// Get a message in English
const englishMessage = await simsimi.getMessage("Hello!");

// Get a message in Spanish
const spanishMessage = await simsimi.getMessage("Hola!", langCode = "es");

// Print the messages
console.log(englishMessage);
console.log(spanishMessage);
